Înainte să începi,

Îți mulțumim că ați ales WebHub pentru achiziționarea componentelor web. Aplicația noastră a fost creată cu gândul la dezvoltatori și designeri ca tine, și suntem încântați să te avem alături în această comunitate.

Ai libertatea deplină de a modifica componentele după bunul tău plac, însă ține cont de faptul că, prin achiziționarea acestora ești în totalitate de acord cu termenii și politicile WebHub în vederea utilizării componentelor web. Pentru mai multe informații referitoare la aceste aspecte te rugăm să vizitezi paginile dedicate în această privință disponibile în cadrul secțiunii "Companie" din subsolul paginii.

De asemenea, dacă ai întrebări suplimentare, nu ezita să ne contactezi prin intermediul căilor de comunicație disponibile în cadrul paginii de Contact ai paginii web și pe suport@webhub.ro.

Cu stimă,

Echipa WebHub